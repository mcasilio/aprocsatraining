###############################################################################
# The following code supports analyses for a submitted manuscript, 'A clinical
# training program for auditory-perceptual rating of connected speech in 
# aphasia.' 

# Last updated by Marianne Casilio on 11/11/2024
# Questions? Email marianne.e.casilio@vanderbilt.edu
###############################################################################

setwd("~/Desktop/research/clinicalaprocsa/submission/analyses") # change as needed

# install packages as needed
install.packages("irr")
install.packages("boot")

library(irr)
library(boot)

# load data
pretrain = read.table("aprocsatraining_pretrain.txt", header = TRUE)
posttrain = read.table("aprocsatraining_posttrain.txt", header = TRUE)
correl = read.table('icc_correl.txt', header = TRUE)

###############################################################################
# Pre/post-training inter-rater agreement with the expert consensus
###############################################################################

##### IF

# Pre-training: .704 [.599, .790]
ilana = cbind(pretrain$IF, pretrain$consensus)
boot_function_ilanapre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_ilanapre = boot(ilana, boot_function_ilanapre, 10000) 
boot_ilanapre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_ilanapre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .728 [.648, .794]
ilanapost = cbind(posttrain$IF, posttrain$consensus)
boot_function_ilanapost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_ilanapost = boot(ilanapost, boot_function_ilanapost, 10000) 
boot_ilanapost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_ilanapost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


###### KC

# Pre-training: .707 [.607, .787]
kelly = cbind(pretrain$KC, pretrain$consensus)
boot_function_kellypre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_kellypre = boot(kelly, boot_function_kellypre, 10000) 
boot_kellypre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_kellypre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .709 [.615, .780]
kellypost = cbind(posttrain$KC, posttrain$consensus)
boot_function_kellypost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_kellypost = boot(kellypost, boot_function_kellypost, 10000) 
boot_kellypost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_kellypost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


##### ZD

# Pre-training: .667 [.549, .760]
zach = cbind(pretrain$ZD, pretrain$consensus)
boot_function_zachpre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_zachpre = boot(zach, boot_function_zachpre, 10000) 
boot_zachpre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_zachpre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .711 [.595, .794]
zachpost = cbind(posttrain$ZD, posttrain$consensus)
boot_function_zachpost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_zachpost = boot(zachpost, boot_function_zachpost, 10000) 
boot_zachpost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_zachpost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


##### JS

# Pre-training: .584 [.469, .683]
jacqueline = cbind(pretrain$JS, pretrain$consensus)
boot_function_jacquelinepre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_jacquelinepre = boot(jacqueline, boot_function_jacquelinepre, 10000) 
boot_jacquelinepre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_jacquelinepre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .690 [.582, .774]
jacquelinepost = cbind(posttrain$JS, posttrain$consensus)
boot_function_jacquelinepost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_jacquelinepost = boot(jacquelinepost, boot_function_jacquelinepost, 10000) 
boot_jacquelinepost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_jacquelinepost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


#### JK

# Pre-training: .599 [.473, .709]
jennifer = cbind(pretrain$JK, pretrain$consensus)
boot_function_jenniferpre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_jenniferpre = boot(jennifer, boot_function_jenniferpre, 10000) 
boot_jenniferpre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_jenniferpre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .620 [.503, .711]
jenniferpost = cbind(posttrain$JK, posttrain$consensus)
boot_function_jenniferpost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_jenniferpost = boot(jenniferpost, boot_function_jenniferpost, 10000) 
boot_jenniferpost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_jenniferpost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


#### KM

# Pre-training: .716 [.625, .792]
keely = cbind(pretrain$KM, pretrain$consensus)
boot_function_keelypre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_keelypre = boot(keely, boot_function_keelypre, 10000) 
boot_keelypre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_keelypre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .694 [.590, .781]
keelypost = cbind(posttrain$KM, posttrain$consensus)
boot_function_keelypost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_keelypost = boot(keelypost, boot_function_keelypost, 10000) 
boot_keelypost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_keelypost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


##### SS

# Pre-training: .891 [.799, .946]
stacey = cbind(pretrain$SS, pretrain$consensus)
boot_function_staceypre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_staceypre = boot(stacey, boot_function_staceypre, 10000) 
boot_staceypre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_staceypre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .990 [.971, .997]
staceypost = cbind(posttrain$SS, posttrain$consensus)
boot_function_staceypost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_staceypost = boot(staceypost, boot_function_staceypost, 10000) 
boot_staceypost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_staceypost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


##### KS

# Pre-training: .682 [.564, .776]
kiiya = cbind(pretrain$KS, pretrain$consensus)
boot_function_kiiyapre = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_kiiyapre = boot(kiiya, boot_function_kiiyapre, 10000) 
boot_kiiyapre # original = intra-class correlation coefficient
boot.ci(boot.out = boot_kiiyapre,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval

# Post-training: .683 [.574, .774]
kiiyapost = cbind(posttrain$KS, posttrain$consensus)
boot_function_kiiyapost = function(data,x)
{
  df = data[x,]
  c(icc(df[,1:2], model ="twoway", type = "agreement", unit = "single")[[7]])
} 
set.seed(42)
boot_kiiyapost = boot(kiiyapost, boot_function_kiiyapost, 10000) 
boot_kiiyapost # original = intra-class correlation coefficient
boot.ci(boot.out = boot_kiiyapost,
        type = c("bca")) # BCa = bootstrapped 95% confidence interval


##### Summary of group-level inter-rater agreement results

preICCs = cbind(.704, .707, .667, .584, .599, .716, .891, .682)
preICCs_lb = cbind(.599, .607, .549, .469, .473, .625, .799, .564)
preICCs_ub = cbind(.790, .787, .760, .683, .709, .792, .946, .776)
postICCs = cbind(.728, .709, .711, .69, .62, .694, .99, .683)
postICCs_lb = cbind(.648, .615, .595, .582, .503, .590, .971, .574)
postICCs_ub = cbind(.794, .780, .794, .784, .711, .781, .997, .774)

allICCs = rbind(preICCs, preICCs_lb, preICCs_ub, postICCs, postICCs_lb, postICCs_ub)
write.table(allICCs, "allICCs.txt")

wilcox.test(postICCs, preICCs, "greater", paired = TRUE) # p = .027

mean(.704, .707, .667, .584, .599, .716, .891, .682) # .704, pre-training
mean(.728, .709, .711, .69, .62, .694, .99, .683) # .728, post-training

##### Exploratory correlations

# ICC pre-/post- change and years of clinical practice
cor(correl[,2:3], method = c("kendall")) # -.473

# ICC pre-/post- change and pre-training confidence in discourse analysis
correl2 = cbind(correl[,2], correl[,4])
cor(correl2, method = c("kendall")) # -.138
